function navigateToLogin() {
  window.location.href = "login.html";
}

function navigateToRegister() {
  window.location.href = "register.html";
}

function navigateToUnemployment() {
  window.location.href = "unemploymentData.html";
}

