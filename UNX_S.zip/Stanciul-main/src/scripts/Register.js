function navigate() {
    window.location.href = 'home.html';
}